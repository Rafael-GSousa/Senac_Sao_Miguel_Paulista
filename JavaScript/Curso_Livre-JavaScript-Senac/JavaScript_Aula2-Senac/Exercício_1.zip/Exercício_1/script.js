var nome = prompt('Qual é o seu nome?')
var idade = prompt('Qual é a sua idade')
var cidade = prompt('Em qual cidade você mora?')
var hobby = prompt('Qual é o seu hobby favorito?')
var estilo = prompt('Qual é o seu estilo musical preferido?')


document.write('Olá, já sei que seu nome é ' + nome + ', possui ' + idade + ' anos, mora em ' + cidade + ', gosta de ' + hobby + ' e seu gosto musical é ' + estilo + '.');

